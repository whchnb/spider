# -*- coding: utf-8 -*-

# Scrapy settings for oldCustomer project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://doc.scrapy.org/en/latest/topics/settings.html
#     https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://doc.scrapy.org/en/latest/topics/spider-middleware.html
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
BOT_NAME = 'oldCustomer'
LOG_FILE = 'customer.log'
LOG_LEVEL = 'INFO'
SPIDER_MODULES = ['oldCustomer.spiders']
NEWSPIDER_MODULE = 'oldCustomer.spiders'

# Crawl responsibly by identifying yourself (and your website) on the user-agent
# USER_AGENT = 'oldCustomer (+http://www.yourdomain.com)'

# Obey robots.txt rules
ROBOTSTXT_OBEY = False

# Configure maximum concurrent requests performed by Scrapy (default: 16)
CONCURRENT_REQUESTS = 60

# Configure a delay for requests for the same website (default: 0)
# See https://doc.scrapy.org/en/latest/topics/settings.html#download-delay
# See also autothrottle settings and docs
# DOWNLOAD_DELAY = 3
# The download delay setting will honor only one of:
# CONCURRENT_REQUESTS_PER_DOMAIN = 16
# CONCURRENT_REQUESTS_PER_IP = 16

# Disable cookies (enabled by default)
COOKIES_ENABLED = False

# Disable Telnet Console (enabled by default)
# TELNETCONSOLE_ENABLED = False

# Override the default request headers:
# DEFAULT_REQUEST_HEADERS = {
#     'accept-encoding': 'gzip, deflate, br', 'authority': 'alicrm.alibaba.com',
#      'content-type': 'application/json;charset=UTF-8',
#      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
#      'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8,en-US;q=0.7', 'scheme': 'https',
#      'referer': 'https://alicrm.alibaba.com/', 'accept': '*/*',
#      'cookie': 'ali_intl_firstIn=n; _uab_collina=155488795789770047854919; _umdata=G9F7476EF4A4364B30686830E67A27797CFF84E; xman_us_t=ctoken=4ohk2vzzq5ot&l_source=alibaba&x_user=51AI2pK6/L7VlLQehGk49DdQG8awdh8vxyqcON730NU=&x_lid=cn1520818028imrv&sign=y&need_popup=y; v=0; isg=BDIyfy4CuqEA1YbcnyLHQpV6iHjUazdgoAaAR_wLXuXQj9KJ5FOGbTjte2KW_671; UM_distinctid=16a0673902d36d-04e5559711d9f3-7f41380f-75300-16a0673902e940; ali_apache_id=11.9.13.76.1557150759624.766351.2; acs_usuc_t=acs_rt=177005a9e61042f59f128bc79982e7e8; cookie2=1ac7fa25536726170bcf8e365d1d6dac; csg=7bc62cd9; _tb_token_=37357e7e6ee33; t=322b772015d101c56fcbc03e684d3e6c; gangesweb-buckettest=223.11.25.171.1557150772434.9; xman_us_f=x_locale=zh_CN&x_l=1&last_popup_time=1557150769789&x_user=CN|Ady|Jakcom|cgs|230927796&no_popup_today=n; cna=cqE0FWxWMHkCAbe453cj97xA; intl_common_forever=X+RjZPMpjwN+YINq3UmTG371UQSHEQrA9Ea5r5cMdtUQxXDfew+mcw==; xman_f=+XlzEk6Rc47+mjk55nZ1R8yie0DqYYqaxyBfr+aoHm7gRQZplqQrRdTgWg6TmXjHn19G9vK7jwwfhc4SUZ+MNpJaIDdNZgh26p1SJRFPVkGIycmspSgI6CYtTbVl3UIW/asg5HEo5SDZjTgkMZwpUzeyRzMjH34hg4l5KaIyrDsSfIx0Dd3kPjtjK4lSUGjrAFeg5wt5rnkGgrzSihcu4bw2qU+LqsnPf3c6x19717eTbGxPxZReTROAFuaRWvNUVmQf4jD122hG+GBlyttljwEmDHw/yuB1k8bdgaa/U8hMMqQXgNocfoVhiH4ftVp4dPw0Q09my6LqXQ7mMtSmDBsRzZRnlAGvogcIj9e7NCNdtmSWz+enyxH2LaTLQnYqD/fn5F+8n20=; intl_locale=zh_CN; _hvn_login=4; ali_apache_tracktmp=W_signed=Y; l=bB_mT0L4vnRV7ScSKOCiNuI8LVQOSCOAguPRwCfdi_5dxOL64e_OlHU8xHp6VffRsVYBqaaJOhw9-etki; JSESSIONID=D27167230EA87C5AD9C2AA4A9BDBE6FF; ali_apache_track=ms=|mt=3|mid=cn1520818028imrv; xman_t=UpvcILwN/gOPSjSBfY0u8zzP+lH3gjLrxbQSTxFb8XiZPAw/DP9P1krC1trBqqw5iCtDgcsvNjh2X9lqwwfDqy9nqO1zlA7AeYlX6MKktkTFUtQiNvJZfKAxlyQKq1A4SaPWRixAaBUO9sExW9AMSGBYTEvRrlrCwOaYYJRjXZDKsCcZwiR9h8ICVrSpEC/0jpa+vekL+7ICotZapG9DhNKTvZCLm0bugf0Jz8t2xYHk3z8UcJunlC2pdcBKERfme2qTJNk9EuX9sWntheYGuDPvy6jx8Cn2V0IJVWmJzW3mPMjA/uXVAr5xfwps3QWnGz75Nq2qjYvL2iAeieCTbnqNhv/6bqv4bLSawLu8eHSpUAV0CnE6uprW1gZDaegxe11lV5TU59GlXj8XbXnCas7nx9Obgy/rpH7ss5qmcxZRiuXcOtpp2eM0oKNQZ1sdgOgb7ueZALzexf3jbTrMPTBsZbnsD3/jpxr28oQuEeahRItftskeM3SEIG/sm2FI18T2Z9tuvdN/G7WjrFJAtqMEFmWO3Bfkl2yl1rJIesoWUNqrh1aiJDjHthAIV6svfONXqpzlafpY0ye1AuXPmnZrB3PxK9aelvcsL+sYc3NreKwgUfTtPkxwWaUJos+fiAGm4ozsln+7ArAv/GEGpvNVr7WufkJcLHnfLiVv9M8=;',
#      'origin': 'https://alicrm.alibaba.com'
# }


# Enable or disable spider middlewares
# See https://doc.scrapy.org/en/latest/topics/spider-middleware.html
# SPIDER_MIDDLEWARES = {
#    'oldCustomer.middlewares.OldcustomerSpiderMiddleware': 543,
# }

# Enable or disable downloader middlewares
# See https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
DOWNLOADER_MIDDLEWARES = {
    'oldCustomer.middlewares.OldcustomerDownloaderMiddleware': 543,
    # 'oldCustomer.middlewares.HeadersDownloadMiddleware': 544,
}

# Enable or disable extensions
# See https://doc.scrapy.org/en/latest/topics/extensions.html
# EXTENSIONS = {
#    'scrapy.extensions.telnet.TelnetConsole': None,
# }

# Configure item pipelines
# See https://doc.scrapy.org/en/latest/topics/item-pipeline.html
ITEM_PIPELINES = {
   'oldCustomer.pipelines.OldcustomerPipeline': 300,
}

# Enable and configure the AutoThrottle extension (disabled by default)
# See https://doc.scrapy.org/en/latest/topics/autothrottle.html
# AUTOTHROTTLE_ENABLED = True
# The initial download delay
# AUTOTHROTTLE_START_DELAY = 5
# The maximum download delay to be set in case of high latencies
# AUTOTHROTTLE_MAX_DELAY = 60
# The average number of requests Scrapy should be sending in parallel to
# each remote server
# AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0
# Enable showing throttling stats for every response received:
# AUTOTHROTTLE_DEBUG = False

# Enable and configure HTTP caching (disabled by default)
# See https://doc.scrapy.org/en/latest/topics/downloader-middleware.html#httpcache-middleware-settings
# HTTPCACHE_ENABLED = True
# HTTPCACHE_EXPIRATION_SECS = 0
# HTTPCACHE_DIR = 'httpcache'
# HTTPCACHE_IGNORE_HTTP_CODES = []
# HTTPCACHE_STORAGE = 'scrapy.extensions.httpcache.FilesystemCacheStorage'
