# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import requests
from oldCustomer.items import InfoItem, ChatItem, InquiryItem



class OldcustomerPipeline(object):
    def process_item(self, item, spider):
        if isinstance(item, InfoItem):
            info_url = 'http://192.168.1.160:90/AlibabaCustomerInfo/customerinfo_save'
            response = requests.post(info_url, data=item)
            print(response)
            print('客户信息', response.text)
        if isinstance(item, ChatItem):
            info_url = 'http://192.168.1.160:90/AlibabaCustomerInfo/customer_chat_save'
            response = requests.post(info_url, data=item)
            print(response)
            print('聊天内容', response.text)
        if isinstance(item, InquiryItem):
            info_url = 'http://192.168.1.160:90/AlibabaCustomerInfo/customer_inquiry_save'
            response = requests.post(info_url, data=item)
            print(response)
            print('询盘内容', response.text)
        return item
