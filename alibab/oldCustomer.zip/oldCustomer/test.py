# encoding: utf-8
"""
@author: Liwenhao
@e-mail: wh.chnb@gmail.com
@file: test.py
@time: 2019/5/28 13:33
@desc:
"""
a = 4 % 7
print(a)